%RLS������������
clear 
clc
d=xlsread('data2');
s=d(:,3);
y_n=[s(6)];
z_n=[s(5) s(4) s(3) s(2) s(1) 1];
for k=7:50
    z_n=[z_n;s(k-1) s(k-2) s(k-3) s(k-4) s(k-5) 1];
    y_n=[y_n;s(k)];
end
ea=inv(z_n'*z_n)*z_n'*y_n;
 estimate=[];
p_n=inv(z_n'*z_n);
 for k=51:length(s)
    z_h=[s(k-1) s(k-2) s(k-3) s(k-4) s(k-5) 1];
    z_n=[z_n;z_h];
    y_n=[y_n;s(k)];
    p_n=inv(inv(p_n)+z_h'*z_h);
    K=1/(1+z_h*p_n*z_h')*p_n*z_h';
    ea=ea+K*(s(k)-z_h*ea);
    estimate=[estimate,ea];
end
res=zeros(1,length(s));
err=res;
for k=7:length(s)
     z_h=[s(k-1) s(k-2) s(k-3) s(k-4) s(k-5) 1];
     res(k)=ea'*z_h';
     err(k)=res(k)-s(k);
end
res(1:6)=s(1:6);
figure;plot(d(:,2),s,'b'); hold on, plot(d(:,2),res,'r');
figure;plot(d(:,2),err);
