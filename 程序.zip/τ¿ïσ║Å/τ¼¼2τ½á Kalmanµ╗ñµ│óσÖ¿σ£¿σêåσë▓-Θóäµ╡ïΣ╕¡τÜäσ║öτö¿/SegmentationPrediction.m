% input
%     signal:     the input signal sequence, a n*1 matrix
%     alpha:      the frequency-agile,which is always set as 1/20;
% output
%     volume:       refers to position
%      speed:       refers to velocity
%       acce:       refers to acceleration
%    diff_acce:     refers to the derivative of acceleration 
%         B:        the slopes of AR prediction function
%       TTT:        the goodness-of-fit of AR prediction function

function [volume,speed,acce,B,TTT] = SegmentationPrediction(signal,w,R)

 % the median Filter
 data_0 = MedianFilter(signal,w);
%  % the moving average Filter
 data = movingavg(data_0,w);
 
 % the maximum of maneuvering acceleration  
 xamax=1;
 
 %the variance of manuvering acceleration
 qq=(xamax)^2*(4-pi)/pi;
 
 %  the length of the interval between two signals
 T = 1;
 
 % the observation noice covariance matrix, which is 1*1 matrix              
 [~, X_c] = KalmanFilterCA(data,qq, R, T);
 xl = X_c;          %Kalman�˲������ƽ��
 figure           %ͼ2.4
 subplot(3,1,1);
 plot(signal,'k');
 xlabel('ʱ��');
 ylabel('�洢����');
 title('ԭʼ�洢����');
 ylim([0 10000]);
 subplot(3,1,2);
 plot(data_0,'k');
 xlabel('ʱ��');
 ylabel('�洢����');
 title('��ֵ�˲���洢����');
 subplot(3,1,3);
 plot(data,'k');
 xlabel('ʱ��');
 ylabel('�洢����');
 title('�ƶ�ƽ����洢����');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
volume = xl(1,:);  %�洢����
speed = xl(2,:);   %�ٶ�
acce = xl(3,:);    %���ٶ�


figure              %ͼ2.5
subplot(3,1,1)
plot(volume,'k');hold on
title('Kalman�����˲���洢����');
 xlabel('ʱ��');
 ylabel('�洢����');
 ylim([0 10000]);

subplot(3,1,2)
plot(speed,'k');hold on
title('�ٶ�');
 xlabel('ʱ��');
 ylabel('�洢����');

subplot(3,1,3)
plot(acce,'k');hold on
title('���ٶ�');
 xlabel('ʱ��');
 ylabel('�洢����');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  ���ٶ��źŷ������   %%%%%%%%%%%%%%%%%%%%%%%%
prob3 = variance_test(acce,w);   %�������
sub_section3=find(prob3>=0.999994);  
% sub_section3=find(prob3==1); 
for j=1:length(sub_section3)
    break_point3(j)=data(sub_section3(j)); 
    break_point30(j)=acce(sub_section3(j));
end

figure                                       %ͼ2.6
% subplot(2,1,1);
plot(data(:,1),'k');hold on
plot(sub_section3,break_point3,'r*');
legend('ԭʼʱ������','Kalman\_Anova�����ٶ��źŵõ��ķָ��')
xlabel('ʱ��');
ylabel('�洢����');

%%%%%%�Լ��ٶ��źŷ������������зֶΣ��������Իع�ģ������Ԥ��
sub = sub_section3;  %1Ϊ�����ź�,2Ϊ���ٶ��ź�,3Ϊ���ٶ��ź�,4Ϊ���ٶȵĵ����ź�
j = 1;
%sub_new is the segmentation matrix
sub_new(j) =1;    
j = j+1;
 for i=2:length(sub)-1
    sub_new(j) = sub(i);
    j=j+1;
 end
 sub_new(j) = sub(length(sub));
 sub_new(j+1) = length(signal);

N = length(sub_new);
j=1;
figure                 %ͼ2.7
plot(signal,'k');hold on
 for i=1:N-1  
    start = sub_new(i);  
    last = sub_new(i+1);   
    row = start:last;
    sig = xl(1,row)';  
if last-start>=200
   [~,  start_pos, b, r2_ma, ~] = lineartrend(sig,w,start);  %�������ģ��
   [~,start,len,t,~] = trend_linear(sig,start_pos,b,r2_ma,start);
   B(1,j)=b(1);
   B(2,j)=b(2);
   TTT(j)={t};
   X(1,j)= start_pos+start;
   X(2,j)= len+start;
   Y_hat(1,j)= [X(1,j) 1]*[B(1,j) B(2,j)]';
   Y_hat(2,j)= [X(2,j) 1]*[B(1,j) B(2,j)]' ;
   c=num2str(j);
   c=[' ',c];
   j=j+1;
 end
 end
p=plot(X,Y_hat,'r-');
set(p, 'LineWidth', 3);
legend(p,TTT);
xlabel('ʱ��');
ylabel('�洢����');
title('�������Ԥ��洢����');
end

%The median Filter
function L = MedianFilter(s, w)
    len = length(s);
    L = zeros(len, 1);
    for i=1:len
        left = i - floor(w/2);
        right = i + floor(w/2);
        if (left < 1) 
            left = 1;
        end
        if (right > len)
            right = len;
        end
        L(i) = median(s(left:right));
    end

end

% The moving average filter
function ma = movingavg(sig, w)

n = length(sig);
    ma = zeros(n, 1);
    c = floor(w/2);
    for i=1:n
        left = i - c;
        right = i + c;
        if left < 1
            left = 1;
        end
        if right > n
            right = n;
        end
        ma(i) = mean(sig(left:right));
    end

end

% analysis of variance
function prob=variance_test(signal1,w)
    
    d1 = signal1;
    len = length(d1);
    prob = zeros(len, 1);
    j=1;
    
    for i=w+1:len-w
        
        L = d1(i-w:i-1);
        R = d1(i+1:i+w);
        [~, p]=vartest2(L,R);
        prob(j) = 1-p;
        j=j+1;
         
    end
    
end

% The linear regression model 
function [w,  start_pos, b, r2_ma,r2_sig]=lineartrend(sig,w,start)

%%%%%%  sig  ��N*1 ����   
    len = length(sig);
    ma = movingavg(sig, w);

    cwt_res = cwt(ma, w, 'db4');       %С���任 wout�Ǵ��ڿ���
    o = detectoutliers(cwt_res, w*7);
    
    if (length(o) >= 1)
        start_pos = max(o) + 1 ;
    else
        start_pos = 1;
    end

    if (len - start_pos < 1000)
        start_pos = 1;
    end

    y = ma(start_pos:len);
    y1 = sig(start_pos:len);
    x1 = (start_pos+start:len+start)';                  % ������
    x0 = ones(len - start_pos + 1, 1);
    x = [x1 x0];
    [b, ~, ~, ~, ~] = regress(y, x);
    y_hat = x*b;

    sse = var(y)*(length(y)-1);
    err = y_hat - y;
    sst = sum(err.*err);
    r2_ma = 1 - sst/sse; 

    sse = var(y1)*(length(y1)-1);
    err = y_hat - y1;
    sst = sum(err.*err);
    r2_sig = 1 - sst/sse;           %����Ŷ�R_2
    
   
end

% The outlier detector
function o = detectoutliers(cwt_res, w)
    o = [];
    len = length(cwt_res);
    if (len <= w)
        o = [];
        return;
    end
    
    start_pos = ceil(w/2);
    end_pos = len-ceil(w/2);
    sig = cwt_res(start_pos:end_pos);
    
    n = 0;
    n1 = -1;
    o1 = [];
    while (n ~= n1)
        o = o1;
        mu = mean(sig);
        sigma = std(sig);
        o1 = find(abs(sig-mu)./sigma>3);
        n = length(o);
        n1 = length(o1);
    end
    o = o + start_pos;
end

% linear trend model
 function [x1,start,len,t,y_hat]= trend_linear(sig,start_pos,b,r2_ma,start)
%  sig��1*N�ľ���
len = length(sig) ;
x1 = (start_pos:len)'+start;
x0 = ones(len-start_pos+1, 1);
x = [x1 x0];
y_hat = x*b;
t = sprintf('R^2=%g', r2_ma);

end

%% CA Kalman Filter with Singer model
% input
%     X: the input signal sequence, a n*1 matrix
%     q: the process noise variance
%     r: the observation noise variance
%     T: the length of the interval between two signals
% output
%     X_p: the predicted values produced by kalman filtering
%          it is a 3*n matrix
%              row 1 refers to position
%              row 2 refers to velocity
%              row 3 refers to acceleration
%     X_c: the corrected values after kalman filtering sees the
%          real value of the signal
%          it is a 3*n matrix, same as predict_sig
function [X_p, X_c] = KalmanFilterCA(X, q, r, T)
% initialize
    n = length(X);
    if (n < 5)
        disp('length of x must be >= 5');
        return;
    end
    X_p = zeros(3, n);
    X_c = zeros(3, n);
    
% initial values
    % the process transformation matrix
    A = [1 T T^2/2;
         0 1 T;
         0 0 1];
    
    % the process noice covariance matrix 
    Q = [T^6/36 T^5/12 T^4/6;
         T^5/12 T^4/4  T^3/2;
         T^4/6  T^3/2  T^2]*q;
    
    % the observation noice covariance matrix
    R = r; %1*1 matrix;
    
    % the observation transformation  
    H = [1 0 0]; %observes position only

    % the initial corrected value
    x_c = [mean(X(1:5)); %position
           0;            %velocity
           0];           %acceleration
    
    % the initial process noice matrix
    P_c = 10*eye(3); %var(X(1:5))*eye(3)
    
    for i=1:n
        [x_p, P_p] = KalmanPredict(x_c, A, P_c, Q);
        [x_c, P_c] = KalmanCorrect(X(i), x_p, P_p, H, R);
        X_p(:,i) = x_p;
        X_c(:,i) = x_c;
    end
end

% prediction: project x and P ahead
function [x_p, P_p] = KalmanPredict(x, A, P, Q)
    x_p = A*x;
    P_p = A*P*A' + Q;
end

%correction: correct x and P according to observed value
function [x_c, P_c] = KalmanCorrect(x_t, x_p, P_p, H, R)
    K = P_p*H'/(H*P_p*H'+R);
    x_c = x_p + K*(x_t - H*x_p);
    P_c = (eye(size(P_p))-K*H)*P_p;
end