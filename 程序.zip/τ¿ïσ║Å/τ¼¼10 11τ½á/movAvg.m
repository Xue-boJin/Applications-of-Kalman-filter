 function avgData=movAvg(original_data,m)
        L=length(original_data);
        avgData=zeros(1,L);
        c=floor(m/2);
        for ci=1:L
            left=ci-c;
            right=ci+c;
            if left<1  
                left=1;
            end
            if right>L 
                right=L;
            end
            avgData(ci)=mean(original_data(left:right));
        end
    end