function QQ=Normalize(QQ)

 q0=QQ(1); 
 q1=QQ(2); 
 q2=QQ(3); 
 q3=QQ(4);
 q0=q0/(sqrt(q0^2+q1^2+q2^2+q3^2));
 q1=q1/(sqrt(q0^2+q1^2+q2^2+q3^2));
 q2=q2/(sqrt(q0^2+q1^2+q2^2+q3^2));
 q3=q3/(sqrt(q0^2+q1^2+q2^2+q3^2));
QQ(1,1)=q0; 
QQ(2,1)=q1; 
QQ(3,1)=q2; 
QQ(4,1)=q3;
end