function [A,Q,U]=myStarmodel(T,a,qq)
  
A=[1 (1-exp(-a*T))/a;0 exp(-a*T)];

q11=(4*exp(-a*T)-exp(-2*a*T)+2*a*T-3)/2/(a^3);
q12=(1-2*exp(-a*T)+exp(-2*a*T))/2/(a^2);
q22=(1-exp(-2*a*T))/2/a;

Q=qq*[q11 q12;q12 q22];
 
U=[T-(1-exp(-a*T))/a;1-exp(-a*T)];
