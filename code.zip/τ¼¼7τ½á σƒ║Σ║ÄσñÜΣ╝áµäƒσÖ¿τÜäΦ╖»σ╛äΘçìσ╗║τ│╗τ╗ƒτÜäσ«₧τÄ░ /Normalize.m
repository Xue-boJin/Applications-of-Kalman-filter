function QQ=Normalize(QQ,i)
for i=2:length(QQ)
 q0=QQ(1,i); 
 q1=QQ(2,i); 
 q2=QQ(3,i); 
 q3=QQ(4,i);
 q0=q0/(sqrt(q0^2+q1^2+q2^2+q3^2));
 q1=q1/(sqrt(q0^2+q1^2+q2^2+q3^2));
 q2=q2/(sqrt(q0^2+q1^2+q2^2+q3^2));
 q3=q3/(sqrt(q0^2+q1^2+q2^2+q3^2)) ;
QQ(1,i)=q0; 
QQ(2,i)=q1; 
QQ(3,i)=q2; 
QQ(4,i)=q3;
end