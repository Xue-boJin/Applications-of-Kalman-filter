function ma = movingavg(sig, w)
    n = length(sig);
    ma = zeros(n, 1);
    c = floor(w/2);
    for i=1:n
        left = i - c;
        right = i + c;
        if left < 1
            left = 1;
        end
        if right > n
            right = n;
        end
        ma(i) = mean(sig(left:right));
    end
end
