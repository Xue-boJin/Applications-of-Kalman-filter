function [Angel,Acc]=Update(QQ,Initial_angel,Abcc)%[Angel]=Update(QQ,Initial_angel)

L=length(QQ(1,:));
Acc=zeros(3,L);
Angel=zeros(3,L);
Angel(:,1)=Initial_angel;
%%
q0=QQ(1,1); 
 q1=QQ(2,1); 
 q2=QQ(3,1); 
 q3=QQ(4,1);
 
 T11=q0^2+q1^2-q2^2-q3^2;
 T12=2*(q1*q2-q0*q3);
 T13= 2*(q1*q3+q0*q2);
 T21=2*(q1*q2+q0*q3);
 T22=q0^2-q1^2+q2^2-q3^2;
 T23=2*(q2*q3-q0*q1);
 T31=2*(q1*q3-q0*q2);
  T32=2*(q2*q3+q0*q1);
  T33=q0^2-q1^2-q2^2+q3^2;
  TR=[T11 T12 T13;T21 T22 T23;T31 T32 T33];%��Ԫ����ʾ����̬����
  Acc(2,1)=Abcc(1,1)*sin(Angel(3,1)*pi/180)+Abcc(2,1)*cos(Angel(3,1)*pi/180);% Acc(:,1)=TR*Abcc(:,1);%
  %%
for i=2:L
 q0=QQ(1,i); 
 q1=QQ(2,i); 
 q2=QQ(3,i); 
 q3=QQ(4,i);
 
 T11=q0^2+q1^2-q2^2-q3^2;
 T12=2*(q1*q2-q0*q3);
 T13= 2*(q1*q3+q0*q2);
 T21=2*(q1*q2+q0*q3);
 T22=q0^2-q1^2+q2^2-q3^2;
 T23=2*(q2*q3-q0*q1);
 T31=2*(q1*q3-q0*q2);
  T32=2*(q2*q3+q0*q1);
  T33=q0^2-q1^2-q2^2+q3^2;
  TR=[T11 T12 T13;T21 T22 T23;T31 T32 T33];%��Ԫ����ʾ����̬����

    x1=asin(T32);
        if  abs(T32)<1
           x=x1;
       elseif (T32)>=1
           x=pi/2;
       elseif (T32)<=-1
           x=-pi/2;
        end
       
     y1=atan(-T31/T33);  
     if T33>0
         y=y1;
     elseif T33<0&&y1<0
         y=y1+pi;
     else
         T33<0&&y1>0
         y=y1-pi;
     end
 
     z1=atan(-T12/T22);
          if T22<0
                z=z1+pi;
          else
                 if T12<0
                    z=z1;
                else 
                    z=z1+2*pi;
                 end
          end
 Acc(2,i)=Abcc(1,i)*sin(z)+Abcc(2,i)*cos(z);
angel=[x*180/pi;y*180/pi;z*180/pi];%������õ��ĽǶȣ������ƣ�ת��Ϊ�Ƕ���
Angel(:,i)=angel;
% Acc(:,i)=TR*Abcc(:,i);
end
end