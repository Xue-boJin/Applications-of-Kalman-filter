%�Ľ���SHAKF�㷨��
clc
clear
d=xlsread('data2');
s=d(:,3);
xe=zeros(6,1);
p=10*eye(6);
A=[0.0071 0.0160 -0.0597 -0.0602 -0.0113 1;
1 0 0 0 0 0;0 1 0 0 0 0; 0 0 1 0 0 0;0 0 0 1 0 0;0 0 0 0 0 1];
B=[1 0 0 0 0 0;0 0 0 0 0 0;0 0 0 0 0 0;0 0 0 0 0 0;0 0 0 0 0 0;0 0 0 0 0 0]; 
C=[1 0 0 0 0 0];
W=[1 0 0 0 0 0]';
QQ=0.1;
q=1;
RR=1;
r=1;
bb=0.96;
xx=[];
RRR=[];
QQQ=[];
pp=[];
xxx=[];
rr=[];
qq=[];
for i=1:length(s);
dd=(1-bb)/(1-bb^(i+1));
 
xee=A*xe+B*W+q;
pk=A*p*A'+QQ;
r=(1-dd)*r+dd*(s(i)-C*xee);
vv=s(i)-C*xee-r;
RR=(1-dd)*RR+dd*vv*vv';
K=pk*C'*inv(C*pk*C'+RR);
xe=xee+K*(s(i)-C*xee);
ppp=p;
p=(eye(6)-K*C)*pk;
q=(1-dd)*q+dd*(xe-xee);
QQ=(1-dd)*QQ+dd*(K*vv*vv'*K'+p-A*ppp*A');
xx=[xx xe];
RRR=[RRR RR];
QQQ=[QQQ QQ];
pp=[pp pk];
xxx=[xxx xee];
 rr=[rr r];
qq=[qq q];
end
figure
d1=xlsread('data2');
s1=d1(:,1);
s2=d1(:,2);
t1=s2(200:length(s2));
denoise=C*xxx(:,200:length(s));
real1=s1';
real=real1(200:1000);
e=denoise-real;
m=mean(abs(e));
coverance=cov(e);
plot(e);
 
axis([0 800 -0.06 0.08])
ylabel('real and denoise difference value');
xlabel('time/ms');
 
figure
plot(t1,s(200:length(s),:),'g-'),
hold on,
plot(t1,C*xxx(:,200:length(s)),'r-')
 
ylabel('data/mm');
xlabel('time/ms');
legend('the measurement data','the denoise data')
axis([2 10 4.6 5.3])
axes('Position',[0.18,0.62,0.28,0.25]); 
plot(t1,s(200:length(s),:),'g-'),
hold on,
plot(t1,C*xxx(:,200:length(s)),'r-')
 
xlim([5.25,5.6]); 
ylim([4.8,5.2]); 
